package ch.bbw.m151.liquibasedemo.datamodel;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

import jakarta.persistence.*;
import jdk.jfr.Timespan;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

@Getter
@Setter
@Entity
@Table(name = "articles")
public class ArticleEntity{

    @Id
    @GeneratedValue
    @Column(columnDefinition = "uuid")private UUID id;

    @Column(nullable = false)
    String title;

    @Column(length = 500)
    String text;

    @Column
    @Version
    int version;

    @Column
    @CreationTimestamp
    LocalDateTime created_ts;

    @Column
    int category;

}
